// This \f escape sequence is a form feed character 
// It is an old technique and used to indicate a page break. 

public class p4 { 
	public static void main(String[] args) 
	{ 
		System.out.println("Good Morning Students! \f How are you all? "); 
	} 
} 
