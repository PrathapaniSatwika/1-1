// Java Program to Count Number of Vowels 
// in a String in a iterative way 

import java.io.*; 

public class prog1 { 
	public static void main(String[] args) 
	{ 
		String str = "Problem Solving Using Java"; // problem solving using java

			str = str.toLowerCase(); //1

		// toCharArray() is used to convert 
		// string to char array 
		char[] chars = str.toCharArray(); //2

		int count = 0; 

		for (int i = 0; i < str.length(); i++) 
		{ 
			// check if char[i] is vowel 
			if (str.charAt(i) == 'a' || str.charAt(i) == 'e'
				|| str.charAt(i) == 'i'
				|| str.charAt(i) == 'o'
				|| str.charAt(i) == 'u') 
			{ 
				// count increments if there is vowel in 
				// char[i] 
				count++; 
			} 
		} 

		// display total count of vowels in string 
		System.out.println("Total no of vowels in string are: " + count); 
	} 
}
