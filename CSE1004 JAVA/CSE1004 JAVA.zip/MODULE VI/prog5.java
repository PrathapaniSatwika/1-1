/**
 * Replace consonants with next immediate consonants alphabetically in a String
 * 
 * 
 * Given a string which contains lowercase English alphabets. The task is to replace each consonant with the next immediate consonant that comes in English alphabets.

Let’s say we have to replace character a, it will be replaced by b. Another example, let’s say we have to replace character d, the next immediate consonant is f, hence d will be replaced by f.

Note: If the character is ‘z’, then look circularly in English alphabets for the next consonant, i.e. replace it with ‘b’.
 * 
 * Approach
 * Iterate the string elements from left to right.
*It the string element is consonant, then check the next immediate alphabet of this element.
*If the next immediate alphabet is a consonant, then replace it with the this alphabet. If it is a vowel, then replace the string element with 2nd immediate alphabet as there are no consecutive vowels in English alphabets.
 * 
 * The java string valueOf() method converts different types of values into string. By the help of string valueOf() method, you can convert int to string, long to string, boolean to string, character to string, float to string, double to string, object to string and char array to string.
 */
// Java program of above approach 
class prog5 
{ 

	// Function to check if a character is 
	// vowel or not 
	static boolean isVowel(char ch) 
	{ 
		if (ch != 'a' && ch != 'e' && ch != 'i'
				&& ch != 'o' && ch != 'u') 
		{ 
			return false; 
		} 
		return true; 
	} 

	// Function that replaces consonant with 
	// next immediate consonant alphabatically 
	static String replaceConsonants(char[] s) 
	{ 
		// Start traversing the string 
		for (int i = 0; i < s.length; i++) 
		{ 
			if (!isVowel(s[i])) 
			{ 

				// if character is z, 
				// than replace it with character b 
				if (s[i] == 'z') 
				{ 
					s[i] = 'b'; 
				} 
				
				// if the alphabet is not z 
				else
				{ 

					// replace the element with 
					// next immediate alphabet 
					s[i] = (char) (s[i] + 1); 

					// if next immediate alphabet is vowel, 
					// than take next 2nd immediate alphabet 
					// (since no two vowels occurs consecutively 
					// in alphabets) hence no further 
					// checking is required 
					if (isVowel(s[i])) 
					{ 
						s[i] = (char) (s[i] + 1); 
					} 
				} 
			} 
		} 
		return String.valueOf(s); 
	} 

	// Driver code 
	public static void main(String[] args) 
	{ 
		String s = "Vitapuniversity"; 
		System.out.println(replaceConsonants(s.toCharArray())); 
	} 
} 

