// This \' escape sequence is for printing a single quotation mark on the text string 

public class p3 { 
	public static void main(String[] args) 
	{ 
		System.out.println("Good Morning \'Students!\' How are you all? "); 
	} 
} 
