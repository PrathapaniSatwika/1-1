// Java program to generate a 
// string whose substrings of 
// length K concatenates to 
// form given strings 
class pviii{ 
	
    // Function to return the required 
    // required string 
    public static void decode_String(String str, 
                                    int K) 
    { 
        String ans = ""; 
        
        // Iterate the given string 
        for(int i = 0; 
                i < str.length(); i += K) 
            
        // Append the first 
        // character of every 
        // substring of length K 
        ans += str.charAt(i); 
        
        // Consider all characters 
        // from the last substring 
        for(int i = str.length() - (K - 1); 
                i < str.length(); i++) 
        ans += str.charAt(i); 
        
        System.out.println(ans); 
    } 
    
    // Driver code 
    public static void main(String[] args) 
    { 
        int K = 3; 
        String str = "abcbcscsesesesd"; 
        
        decode_String(str, K); 
    } 
    } 
    
    