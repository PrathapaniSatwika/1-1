/**
 * Minimum changes to a string to make all substrings distinct
Given a string, find minimum number of changes to it so that all substrings of the string become distinct.

Examples :

Input :  str = "aab"
Output : 1
If we change one instance of 'a'
to any character from 'c' to 'z',
we get all distinct substrings.

Input : str = "aa"
Output : 1

To make all substrings distinct, every character must
 be different. So we simply need to count number of 
 repeated characters. If length of string is more than
  26, then we cannot convert it into a string with all
   distinct substrings (Here we assume that string 
   should contain only lower case characters, ‘a’ to 
   ‘z’)
 */

 // JAVA program to count number of changes 
// to make all substrings distinct. 
import java.lang.*; 
import java.util.*; 

class pxx 
{ 
	static final int MAX_CHAR = 26; 
	
	// Returns minimum changes to str so 
	// that no substring is repeated. 
	public static int minChanges(String str) 
	{ 
		
		int n = str.length(); 
		
		// If length is more than maximum 
		// allowed characters, we cannot 
		// get the required string. 
		if (n > MAX_CHAR) 
			return -1; 
		
		// Variable to store count of 
		// distinct characters 
		int dist_count = 0; 
		int count[] = new int[MAX_CHAR]; 
		
		// To store counts of different 
		// characters 
		for(int i = 0; i < MAX_CHAR; i++) 
			count[i] = 0; 
		
		for (int i = 0; i < n; i++) 
		{ 
			if(count[str.charAt(i)-'a'] == 0) 
				dist_count++; 
			count[str.charAt(i)-'a']++; 
		} 
		
		// Answer is, n - number of distinct char 
		return (n-dist_count); 
	} 
	
	//Driver function 
	public static void main (String[] args) { 
		
		String str = "aebaecedabbee"; 
		
		System.out.println(minChanges(str)); 
	} 
} 

