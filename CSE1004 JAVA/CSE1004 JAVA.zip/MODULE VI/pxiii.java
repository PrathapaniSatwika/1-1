/***
 * Number of arguments the concat() method and + operator takes:
concat() method takes only one argument of string and concat it with other string.
+ operator takes any number of arguments and concatenates all the strings.

 * 
 */
public class pxiii { 
	public static void main(String[] args) 
	{ 
		String s = "Java", t = "for", g = "Everyone"; 

		System.out.println(s + t + g); 
		System.out.println(s.concat(t)); 
	} 
} 
