/***
 * Creates a new String object.
concat() method takes concatenates two strings and return new string object only string length is greater than 0, otherwise it returns same object.
+ operator creates a new string object every time irrespective of length of string.

 */
public class pv { 
	public static void main(String[] args) 
	{ 

		String s = "Java", g = ""; 
		String f = s.concat(g); 
		if (f == s) 
			System.out.println("Both are same"); 
		else
			System.out.println("not same"); 
		String e = s + g; 
		if (e == s) 
			System.out.println("Both are same"); 
		else
			System.out.println("not same"); 
	} 
} 
