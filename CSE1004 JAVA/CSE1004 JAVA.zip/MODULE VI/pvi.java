/**
 * Count the number of vowels
 *  occurring in all the substrings of given string
 * 
 * Given a string of length N of lowercase characters containing 0 or more vowels, the task is to find the count of vowels that occurred 
 * in all the substrings of the given string
 * Input: str = “abc”
Output: 3

The given string “abc” contains only one vowel = ‘a’
Substrings of “abc” are = {“a”, “b”, “c”, “ab”, “bc,
     “abc”}
Hence, the sum of occurrences of the vowel in 
these strings = 3.(‘a’ occurred 3 times)


 */

// Java implementation of the above approach 

import java.io.*; 
import java.util.*; 

public class pvi { 

	// Returns the total sum of 
	// occurrences of all vowels 
	static int vowel_calc(String s) 
	{ 
		int n = s.length(); 
		int arr[] = new int[n]; 

		for (int i = 0; i < n; i++) { 

			if (i == 0) 
				// No. of occurrences of 0th character 
				// in all the substrings 
				arr[i] = n; 

			else
				// No. of occurrences of ith character 
                // in all the substrings 
                /**
                 * no. of substrings starting with that character + the number of substrings formed by the previous characters containing this character – the number of substrings 
                 * formed by the previous characters only.
                 */
				arr[i] = (n - i) + arr[i - 1] - i; 
		} 

		int sum = 0; 
		for (int i = 0; i < n; i++) { 
			char ch = s.charAt(i); 
			// Check if ith character is a vowel 
			if (ch == 'a' || ch == 'e' || ch == 'i'
				|| ch == 'o' || ch == 'u') 
				sum += arr[i]; 
		} 

		// Return the total sum 
		// of occurrences of vowels 
		return sum; 
	} 

	// Driver Code 
	public static void main(String args[]) 
	{ 
		String s = "daceh"; 
		System.out.println(vowel_calc(s)); 
	} 
} 
