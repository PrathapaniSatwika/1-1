// Java program to demonstrate 
// working of concat() method 

class pxii { 
	public static void main(String args[]) 
	{ 
		String s1 = "Java"; 
		String s2 = "! is the best"; 

		String s3 = s1 + s2; 

		System.out.println(s3); 
	} 
} 
