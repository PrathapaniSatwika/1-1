// Java Program to Count Number of Vowels 
// in a String in a recursive way 

import java.io.*; 

class prog2 { 

	// isVowel() function returns 1 if the 
	// character is a vowel and 0 if it is not 
	static int isVowel(char chars) 
	{ 
		if (chars == 'a' || chars == 'e' || chars == 'i'
			|| chars == 'o' || chars == 'u') { 
			return 1; 
		} 
		else { 
			return 0; 
		} 
	} 

	// recursive function to return the number 
	// of characters in a string 
	static int vowelno(String str, int l) 
	{ 
		if (l == 1) { 
			return isVowel(str.charAt(l - 1)); 
		} 

		return vowelno(str, l - 1) 
			+ isVowel(str.charAt(l - 1)); 
	} 

	public static void main(String[] args) 
	{ 
		String str = "Problem Solving using Java"; 

		str = str.toLowerCase(); 

		System.out.println( 
			"Total number of vowels in string are:"); 

		System.out.println(vowelno(str, str.length())); 
	} 
}
