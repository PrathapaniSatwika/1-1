// This \\ escape sequence is for printing a backslash on the text string 

public class p1 { 
	public static void main(String[] args) 
	{ 
		System.out.println("\\- this is a backslash. "); 
	} 
} 
