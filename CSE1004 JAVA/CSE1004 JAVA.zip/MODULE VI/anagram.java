/**
 * Method 4 (Taking sum)


We initialize a variable say count to 0.
Then we take the sum of all the characters of the first String and then decreasing the value of all the characters from the second String.
If the Count value finally is 0, i.e.  then its an anagram, else it is not.
 */

// Java program to check if two strings
// are anagrams of each other
class anagram{

    static boolean isAnagram(String c, String d)
    {
        if (c.length() != d.length())
            return false;
            
        int count = 0;
    
        // Take sum of all characters of
        // first String
        for(int i = 0; i < c.length(); i++)
        {
            count = count + c.charAt(i);//implicit
        }
    
        // Subtract the Value of all the characters
        // of second String
        for(int i = 0; i < d.length(); i++)
        {
            count = count - d.charAt(i);
        }
    
        // If Count = 0 then they are anagram
        // If count > 0 or count < 0 then 
        // they are not anagram
        return (count==0);
    }
    
    // Driver code
    public static void main(String[] args)
    {
        String str1 = "acdf";
        String str2 = "abef";
    
        // Function call
        if (isAnagram(str1, str2))
            System.out.print("The two strings are " + 
                            "anagram of each other");
        else
            System.out.print("The two strings are not " + 
                            "anagram of each other");
    }
    }
    
    
 