/***
 * Given a string str consisting of lowercase English alphabets, the task is to count the number of adjacent pairs of vowels.
 * 
 * 
 * Approach: Starting from the first character of the string to the second last character, increment count for every character where str[i] as well as str[i + 1] are both vowels. Print the count in the end which is the required count of pairs.
 */

// Java implementation of the approach 
class prog4 { 

	// Function that return true 
	// if character ch is a vowel 
	static boolean isVowel(char ch) 
	{ 
		switch (ch) { 
		case 'a': 
		case 'e': 
		case 'i': 
		case 'o': 
		case 'u': 
			return true; 
		default: 
			return false; 
		} 
	} 

	// Function to return the count of adjacent 
	// vowel pairs in the given string 
	static int vowelPairs(String s, int n) 
	{ 
		int cnt = 0; 
		for (int i = 0; i < n - 1; i++) { 

			// If current character and the 
			// character after it are both vowels 
			if (isVowel(s.charAt(i)) && isVowel(s.charAt(i + 1))) //true , true
				cnt++; 
		} 

		return cnt; 
	} 

	// Driver code 
	public static void main(String args[]) 
	{ 
		String s = "abaebio"; 
		int n = s.length(); 
		System.out.print(vowelPairs(s, n)); 
	} 
} 


