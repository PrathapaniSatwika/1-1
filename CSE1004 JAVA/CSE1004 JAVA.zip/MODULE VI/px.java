/***
 * 
 * Given a string as an input. We need to write a program that will print all non-empty substrings of that given string.
Input :  abcd
Output :  a 
          b
          c
          d
          ab
          bc
          cd
          abc
          bcd
          abcd

 */

//Java program to print all possible
// substrings of a given string

class px {

    // Function to print all sub strings
        static void subString(char str[], int n) {
            // Pick starting point
            for (int len = 1; len <= n; len++) {
                // Pick ending point
                for (int i = 0; i <= n - len; i++) {
                    // Print characters from current
                    // starting point to current ending
                    // point. 
                    int j = i + len - 1;
                    for (int k = i; k <= j; k++) {
                        System.out.print(str[k]);
                    }
    
                    System.out.println();
                }
            }
        }
    
    // Driver program to test above function
        public static void main(String[] args) {
            char str[] = {'a', 'b', 'c'};
            subString(str, str.length);
    
        }
    }
    