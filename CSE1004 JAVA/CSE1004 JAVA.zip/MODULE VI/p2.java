// This \" escape sequence is for printing a double quotation mark on the text string 

public class p2 { 
	public static void main(String[] args) 
	{ 
		System.out.println("Good Morning \"Students!\" How are you all? "); 
	} 
} 
