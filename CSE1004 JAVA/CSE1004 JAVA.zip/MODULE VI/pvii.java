/**
 * Lexicographically smallest permutation of a string that contains all substrings of another string
Given two strings A and B, the task is to find lexicographically the smallest permutation of string B such that it contains every substring from the string A as its substring. 
Print “-1” if no such valid arrangement is possible.
nput: A = “aa”, B = “ababab” 
Output: aaabbb 
Explanation: 
All possible substrings of A are (‘a’, ‘a’, ‘aa’) 
Rearrange string B to “aaabb”. 
Now “aaabb” is the lexicographically the smallest arrangement of B which 
contains all the substrings of A.
 */

 /**
  * Steps
  Count the frequency of each character in string B in an array freq[] and then subtract from it the frequencies of the corresponding characters in string A.
In order to form lexicographically the smallest string, initialize an empty string result and then append to it, all the leftover characters which are less in value than the first character of string A.
Before appending all the characters equal to the first character A to result, check if there is any character which is less than the first character in string A. If so, then append A to result first and then all the remaining characters equal to the first character of A to make the reordered string lexicographically smallest.
Otherwise, append all remaining occurrences of A[0] and then append A.
At last, append the remaining characters to the result.
After the above steps, print the string result.
  */

  // Java program for 
// the above approach
class pvii{

    // Function to reorder the String B
    // to contain all the subStrings of A
    static String reorderString(char []A, 
                                char []B)
    {
    // Find length of Strings
    int size_a = A.length;
    int size_b = B.length;
    
    // Initialize array to count the
    // frequencies of the character
    int freq[] = new int[300];
    
    // Counting frequencies of
    // character in B
    for (int i = 0; i < size_b; i++)
        freq[B[i]]++;
    
    // Find remaining character in B
    for (int i = 0; i < size_a; i++)
        freq[A[i]]--;
    
    for (int j = 'a'; j <= 'z'; j++) 
    {
        if (freq[j] < 0)
        return "-1";
    }
    
    // Declare the reordered String
    String answer = "";
    
    for (int j = 'a'; j < A[0]; j++)
    
        // Loop until freq[j] > 0
        while (freq[j] > 0) 
        {
        answer+=j;
    
        // Decrement the value
        // from freq array
        freq[j]--;
        }
    
    int first = A[0];
    
    for (int j = 0; j < size_a; j++) 
    {
        // Check if A[j] > A[0]
        if (A[j] > A[0])
        break;
    
        // Check if A[j] < A[0]
        if (A[j] < A[0]) 
        {
        answer += String.valueOf(A);
        A = new char[A.length];
        break;
        }
    }
    
    // Append the remaining characters
    // to the end of the result
    while (freq[first] > 0) 
    {
        answer += String.valueOf((char)first);
        --freq[first];
    }
    
    answer += String.valueOf(A);
    
    for (int j = 'a'; j <= 'z'; j++)
    
        // Push all the values from
        // frequency array in the answer
        while (freq[j]-- > 0)
        answer += ((char)j);
    
    // Return the answer
    return answer;
    }
    
    // Driver Code
    public static void main(String[] args)
    {
    // Given Strings A and B
    String A = "aa";
    String B = "ababab";
    
    // Function Call
    System.out.print(reorderString(A.toCharArray(), 
                                    B.toCharArray()));
    }
    }
    
    