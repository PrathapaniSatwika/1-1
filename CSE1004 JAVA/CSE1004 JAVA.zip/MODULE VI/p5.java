// This \r escape sequence is a carriage return character 
// It moves the output point back to the beginning of the line without moving down a line (usually). 

public class p5 { 
	public static void main(String[] args) 
	{ 
		System.out.println("Good Morning Students! \r How are you all? "); 
	} 
} 
