/**
 * Different substrings in a string that start and end with given strings
 Given a string s and two other strings begin and end, find the number of different substrings in the string which begin and end with the given begin and end strings.

Examples:


Input : s = "vishakha"
        begin = "h"
        end = "a"
Output : 2
Two different sub-strings are "ha" and "hakha".
 */

 /**
  * Find all occurrences of string begin and string 
  end. Store the index of each string in two different
   arrays. After that traverse through whole string 
   and add one symbol per iteration to already seen 
   sub-strings and map new strings to some non-negative integers. As the ends and beginnings of strings and different string of equal length are mapped to different numbers (and equal strings are mapped equally), simply count the
  number of necessary sub-strings of certain length.
  */
  // Java program to find number of 
// different sub stings 
// Java implementation to count 
// substrings starting with 
// character X and ending 
// with character Y 
import java.util.*; 
import java.lang.*; 
import java.io.*; 

class pii 
{ 
// function to count substrings 
// starting with character X and 
// ending with character Y 
static int countSubstr(String str, int n, 
					char x, char y) 
{ 
	// to store total count of 
	// required substrings 
	int tot_count = 0; 

	// to store count of character 
	// 'x' up to the point the 
	// string 'str' has been 
	// traversed so far 
	int count_x = 0; 

	// traverse 'str' form 
	// left to right 
	for (int i = 0; i < n; i++) 
	{ 

		// if true, increment 'count_x' 
		if (str.charAt(i) == x) 
			count_x++; 

		// if true accumulate 'count_x' 
		// to 'tot_count' 
		if (str.charAt(i) == y) 
			tot_count += count_x; 
	} 

	// required count 
	return tot_count; 
} 

// Driver code 
public static void main(String args[]) 
{ 
	String str = "abbcaceghcak"; 
	int n = str.length(); 
	char x = 'a', y = 'c'; 

	System.out.print ("Count = " + 
	countSubstr(str, n, x, y)); 
} 
} 
