/***
 * ype of arguments :
strong>concat() method takes only string arguments, if there is any other type is given in arguments then it will raise an error.
+ operator takes any type and converts to string type and then concatenates the strings.
concat() method raises java.lang.NullPointer Exception
concat() method throws NullPointer Exception when string is concatenated with null
+ operator did not raise any Exception when the string is concatenated with null.

 */
public class pxiv { 
	public static void main(String[] args) 
	{ 
		String s = "Java"; 
		String r = null; 
		System.out.println(s + r); 

		// It raises an NullPointer Exception 
		System.out.println(s.concat(r)); 
	} 
} 

