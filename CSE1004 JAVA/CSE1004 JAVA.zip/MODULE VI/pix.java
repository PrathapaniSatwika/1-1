/**
 * Check if concatenation of splitted substrings of two given strings forms a palindrome or not
 * Given two strings a and b of the same length, the task is to check if splitting both the strings and concatenating their opposite substrings, i.e. concatenating the left substring of a with right substring of b or concatenating the left substring of b with right substring of a, forms a palindrome or not. If found to be true print “Yes”. Otherwise, print “No”.
 * 
 */
/**
 * nput: a = “ulacfd”, b = “jizalu”
Output: True
Explanation: 
Split both the strings at index 3:
Left substring of a (aLeft) = “ula”, Right substring of a (aRight) = “cfd”
, Left substring of b (bLeft) = “jiz”, Right substring of b (bRight) = “alu”
Since aleft + bright = “ula” + “alu” = “ulaalu”, which is a palindrome, print Yes.
 */

 /**
  * Place a pointer i at 0th index of a and “j” at the last index of b.
Iterate over the characters of the string and check if a[i] == b[j], then increment i and decrement j.
Otherwise, just break the loop as its not a palindrome type sequence.
Concatenate aLeft and bRight in a string variable xa and aRight and bLeft in another string variable xb.
Check if either of the tw strings is a palindrome or not. If found to be true, print “Yes”. Otherwise, print “No”.

  */

  // Java program for the above approach 
import java.util.*;

class pix{

// Function to check if concatenating
// opposite subStrings after splitting
// two given Strings forms a palindrome 
// or not
static boolean checkSplitting(String a, String b)
{
	
	// Length of the String
	int len = a.length();
	int i = 0, j = len - 1;
	
	// Iterate through the Strings
	while (i < len)
	{
		
		// If not a palindrome sequence
		if (a.charAt(i) != b.charAt(j)) 
		{
			break;
		}
		i += 1;
		j -= 1;

		// Concatenate left subString of a
		// and right subString of b in xa
		// Concatenate right subString of a
		// and left subString of b in xb
		String xa = a.substring(i, j + 1);
		String xb = b.substring(i, j + 1);

		// Check if either of the two concatenated
		// Strings is a palindrom or not
		if (xa.equals(reverse(xa))||xb.equals(reverse(xb)))
			return true;
	}
	return false;
}

// Function to check if concatenation of splitted
// subStrings of two given Strings forms a palindrome
static void isSplitPossible(String a, String b)
{
	if (checkSplitting(a, b) == true)
	{
		System.out.print("Yes");
	}
	else if (checkSplitting(b, a) == true) 
	{
		System.out.print("Yes");
	}
	else
	{
		System.out.print("No");
	}
}
static String reverse(String input) {
	char[] a = input.toCharArray();
	int l, r = a.length - 1;
	for (l = 0; l < r; l++, r--) {
		char temp = a[l];
		a[l] = a[r];
		a[r] = temp;
	}
	return String.valueOf(a);
}

// Driver Code
public static void main(String[] args)
{
	String a = "ulacfd", b = "jizalu";

	// Function Call
	isSplitPossible(a, b); 
}
}


