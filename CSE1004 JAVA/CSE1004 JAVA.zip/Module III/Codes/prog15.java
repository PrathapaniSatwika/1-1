/*
1
2 4   
3 6 9
4 8 12 16 
5 10 15
6 12 
7 
//4 loops
1 loop = upper limit
2 loop = digits
3 loop = reverse
4 loop = digits
*/

import java.util.Scanner;

public class prog15
{
	public static void main(String[] args)
	{
		// Create a new Scanner object
		Scanner scanner = new Scanner(System.in);

		// Get the number of rows from the user
		System.out.println("Enter the number of rows needed in the pattern ");

		int rows = scanner.nextInt();

		System.out.println("** Printing the pattern... **");

		int temp = 1; 
		for(int i = 1; i <= rows/2+1; i++) // 4x
		{ 
			
			for(int j = 1;j <= i;j++) //i=1
			{ 
				System.out.print(temp*j+" "); //upper 1
			} 
				System.out.println(); 
				temp++; //2
		} //temp = 5
		for(int i = 1; i <= rows/2; i++)//, i=1,i=2,i=3 
		{ 
			for(int j = 1;j <= rows/2+1-i; j++) 
			{ 
				System.out.print(temp*j+" "); 
			} 
			System.out.println(); 
			temp++; 
		}
	}
}