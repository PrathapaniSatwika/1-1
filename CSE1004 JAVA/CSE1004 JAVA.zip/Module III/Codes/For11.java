import java.util.*;
public class For11
{
    public static void main(String[] args)
    {
        int i, num, sum = 0;
        System.out.println("Enter the number");
        Scanner inp = new Scanner(System.in);
        //int i;
        num = inp.nextInt();//num = 10
        if(num!=10);
        { 
            ++num;
        }/***** */
        /***code */
        //for (i = 1;i <= num;i++);/******* */
        //{
        //    sum = sum + i;
        //}
        System.out.println(num);
    }
}