public class demo
{
     public static void main(String[] args) 
    {
        int a = 1;
        for (a = 1; ;a++)
        {
            System.out.print("ok"+" ");
            continue;
        //else 
        } //System.out.println("error");
    }
}