/**According to the rule whenever there is one dimenssional array we can replace the array with var-arg parameter.So here we can change our string array using var-args. (the triple dots instead of []) */


class testyy{ 
	
    final public static void main(String... args){ 
    System.out.println("I'm in SCOPE"); 
} 
} 
