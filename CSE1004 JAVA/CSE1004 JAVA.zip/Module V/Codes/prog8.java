public class prog8
{
    public static void main(String[] args)
    {
        System.out.println("the first 50 numbers are");
        printPrime(50);
    }
    public static void printPrime(int numberofPrimes)
    {
        final int NUMBER_OF_PRIMES = 10;
        int count = 0;
        int number = 2;
        while (count < numberofPrimes)
        {
            if(isPrime(number))
            count++;
            if(count % NUMBER_OF_PRIMES==0){
            System.out.printf("-5s\n", number);
        }
        else{
            System.out.printf("-5s\n",number);
        }
        number++;//check next num as prime
        }
    }
    public static boolean isPrime(int number)
    {
        for(int div=2;div<=number/2;div++)
        {
            if(number%div==0)
            {
                return false;
            }
        }
        return true;
    }
}