/**
 * The Java Math rint() method returns a value that is closest to the specified value and is equal to the mathematical integer.
 * 
 * That is, if the specified value is 5.8, the closest value that is equal to the mathematical integer is 6.0. And, for value 5.4, the closest value that is equal to mathematical integer is 5.0.
 */
class Main {
    public static void main(String[] args) {
  
      // Math.rint()
      // value greater than 5 after decimal
      System.out.println(Math.rint(1.878));  // 2.0
  
      // value less than 5 after decimal
      System.out.println(Math.rint(1.34));   // 1.0
  
      // value equal to 5 after decimal
      System.out.println(Math.rint(1.5));    // 2.0
  
      // value equal to 5 after decimal
      System.out.println(Math.rint(2.5));    // 2.0
  
    }
  }
