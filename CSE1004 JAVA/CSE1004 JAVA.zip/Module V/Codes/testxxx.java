class testxxx { 
	private static void main(String args[]) 
	{ 
		System.out.println("GeeksforGeeks"); 
	} 
} 













/*Error: Main method not found in class GFG, please define the main method as:
   public static void main(String[] args)
or a JavaFX application class must extend javafx.application.Application//applet

Reason: Since the access specifier was changed from “public” to “private” JVM was unable to access/locate the main method.



*/