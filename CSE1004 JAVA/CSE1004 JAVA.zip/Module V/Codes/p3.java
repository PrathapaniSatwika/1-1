/**
 * The addExact() method throws an exception if the result of addition overflows the data type. That is, the result should be within the range of the data type of specified variables.
 * 
 */
import java.lang.Math;

class p3 {
  public static void main(String[] args) {

    // create int variable
    // maximum int value
    int a = 2147483647;
    int b = 1;

    // addExact() with int arguments
    // throws exception
    System.out.println(Math.addExact(a, b));
  }
}


 

/****
 * In the above example, the value of a is the maximum int value and the value of b is 1. When we add a and b,

  2147483647 + 1
=> 2147483648    // out of range of int type     
Hence, the addExact() method throws the integer overflow exception.
 * 
 */