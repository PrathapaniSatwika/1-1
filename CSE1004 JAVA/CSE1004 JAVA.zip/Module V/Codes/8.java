/**
 * The Java Math expm1() method returns the Euler's number e raised to the power of the specified value minus 1.


 */
class Main {
    public static void main(String[] args) {
  
      // Math.expm1() method
      double a = 4.0d;
      System.out.println(Math.expm1(a));  // 53.598150033144236
  
      // without using Math.expm1()
      // value of Euler Number
      double euler = 2.71828d;
      System.out.println(Math.pow(euler, a)-1);  // 53.5980031309658
  
    }
  }

  /***
   * In the above example, we have used the Math.pow() method to compute the e4.0 value. Here, we can see that

Math.expm1(4.0) = e4.0-1
   */