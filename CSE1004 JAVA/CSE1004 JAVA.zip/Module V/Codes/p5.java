/**
 * The Java Math ceil() method rounds the specified double value upward and returns it.


 */
class Main {
    public static void main(String[] args) {
  
      // Math.ceil() method
      // value greater than 5 after decimal
      double a = 1.878;
      System.out.println(Math.ceil(a));  // 2.0
  
      // value equals to 5 after decimal
      double b = 1.5;
      System.out.println(Math.ceil(b));  // 2.0
  
      // value less than 5 after decimal
      double c = 1.34;
      System.out.println(Math.ceil(c));  // 2.0
    }
  }
  