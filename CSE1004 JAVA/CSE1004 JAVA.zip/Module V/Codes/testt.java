public class testt 
{ 
	public String function(String temp, double data, double sum) 
	{ 
		return ("VITAP"); 
	} 
	public String function(String temp, double data) 
	{ 
		return ("Amaravati"); 
	} 
	public static void main(String[] args) 
	{ 
		testt obj = new testt(); 
		System.out.println(obj.function("VIT", 5.3, 20.55f));	 
	} 
} 
