//regarding placement of [] and replacing string in main()
class testy{ 

	public static void main(String[] vit){ 
			System.out.println("Instead of args we have written geeksforgeeks"); 
	} 
} 
