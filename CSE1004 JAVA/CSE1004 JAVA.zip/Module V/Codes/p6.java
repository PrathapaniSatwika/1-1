/**
 * The Java Math floor() method rounds the specified double value downward and returns it.
 */

class Main {
    public static void main(String[] args) {
  
      // Math.floor() method
      // value greater than 5 after decimal
      double a = 1.878;
      System.out.println(Math.floor(a));  // 1.0
  
      // value equals to 5 after decimal
      double b = 1.5;
      System.out.println(Math.floor(b));  // 1.0
  
      // value less than 5 after decimal
      double c = 1.34;
      System.out.println(Math.floor(c));  // 1.0
    }
  }


