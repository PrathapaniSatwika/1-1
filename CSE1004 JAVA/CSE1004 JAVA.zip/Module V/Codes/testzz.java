// Java program to check accessibility 
// of non - static variables inside 
// static mathods 

class testzz { 

	// declaring variable 'a' as non - static 
	//int a = 5; 

	// main is also a static type 
	public static void main(String args[]) 
	{ 
		static int a = 7;
		// accessing value of 
		// non - static variable 
		System.out.println("Non - Static variable:" + a); 
	} 
}
