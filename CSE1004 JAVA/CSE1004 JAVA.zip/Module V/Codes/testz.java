//call main() multiple times

class testz { 

	// static block 
	static
	{ 
		main(new String[] { "VIT" }); 
	} 
	public static void main(String[] args) 
	{ 
		System.out.println("AP"); 
	} 
} 





/***
 *  Static block is executed even before the main() executed. Here first, main() get called by static block and then JVM(Java Virtual Machine) call the main(). So, main() is executed two times by calling only one time.

 */
