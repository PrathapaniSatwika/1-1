import java.util.Scanner;
public class prog1121
{
    public static void main(String[] args) 
    {
        int n, mul;
        Scanner s = new Scanner(System.in);
        System.out.print("Enter any integer:");
        n = s.nextInt();
        Factorial obj = new Factorial();
        mul = obj.fact(n);
        System.out.println("Factorial of "+n+" :"+mul);
    }
    int fact(int x)//5
    {
        if(x > 1)//true
        {
            return(x * fact(x - 1));//5*fact(4)=5*4*fact(3)=5*4*3*fact(2)=5*4*3*2*fact(1)
        }
        return 1;//*** */
    }
}