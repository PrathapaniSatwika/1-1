//Example 2: Java Math abs() with Negative Numbers

import java.lang.Math;

class Main {
  public static void main(String[] args) {

    // create variables
    int a = -35;
    long b = -141224423L;
    double c = -9.6777777d;
    float d = -7.7f;

    // get the absolute value
    System.out.println(Math.abs(a));  // 35
    System.out.println(Math.abs(b));  // 141224423
    System.out.println(Math.abs(c));  // 9.6777777
    System.out.println(Math.abs(d));  // 7.7
  }
}