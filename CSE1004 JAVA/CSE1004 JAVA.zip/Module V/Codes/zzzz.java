/*Method Overloading can be defined as a feature in which a class can have more than one method having the same name if and only if they differ by number of parameters or the type of parameters or both, then they may or may not have same return type. Method overloading is one of the ways that java support Polymorphism.*/
// Java program to demonstrate 
// Overloading of main() 

public class zzzz{ 

	// Overloaded main method 1 
	// According to us this overloaded method 
	// Should be executed when int value is passed 
	public static void main(int args) 
	{ 
		System.out.println("main() overloaded"
						+ " method 1 Executing"); 
	} 

	// Overloaded main method 2 
	// According to us this overloaded method 
	// Should be executed when character is passed 
	public static void main(char args) 
	{ 
		System.out.println("main() overloaded"
						+ " method 2 Executing"); 
	} 

	// Overloaded main method 3 
	// According to us this overloaded method 
	// Should be executed when double value is passed 
	public static void main(double[] args) 
	{ 
		System.out.println("main() overloaded"
						+ " method 3 Executing"); 
	} 

	// Original main() 
	public static void main(String[] args) 
	{ 
		System.out.println("Original main()"
						+ " Executing"); 
	} 
} 









/**As from above example, it is clear that every time original main method executes but not the overloaded methods because JVM only executes the original main method by default but not the overloaded one.
So, to execute overloaded methods of main, we must call them from the original main method.
 */