// Java program to find GCD of two numbers*************much more efficient
/***
 * The algorithm is based on below facts.

If we subtract smaller number from larger (we reduce larger number), GCD doesn’t change. So if we keep subtracting repeatedly the larger of two, we end up with GCD.
Now instead of subtraction, if we divide smaller number, the algorithm stops when we find remainder 0.
 */
class prog10
{
	// Recursive function to return gcd of a and b
	static int gcd(int a, int b)//x, y
	{
	if (b == 0)
		return a;
    return gcd(b, a % b); // 
    
	}
	
	// Driver method
	public static void main(String[] args) 
	{
		int a = 468, b = 24;
		System.out.println("GCD of " + a +" and " + b + " is " + gcd(a, b));
	}
}


/**
 * gcd(468, 24)
gcd(24, 12)
=> 12
gcd(135, 19)
gcd(19, 2)
gcd(2, 1)
=> 1
 */