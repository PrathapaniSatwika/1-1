public class test 
{ 
	public String function(int data, char temp) 
	{ 
		return ("VITAP"); 
	} 
	public String function(char data, String temp) //char>String
	{ 
		return ("Amaravati"); 
	} 
	public static void main(String[] args) 
	{ 
		test obj = new test(); 

		//System.out.printf("%c ",a);
		
		System.out.println(obj.function(" ",56));	 
	 
	} 
} 






/*****order of arguememt is important for function overloading */