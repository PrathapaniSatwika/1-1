import java.util.*;
public class prog7
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner (System.in);
        int n1 = in.nextInt();
        int n2 = in.nextInt();
        System.out.println(gcd(n1,n2));
    }
    public static int gcd(int n1, int n2)
    {
        int gcd = 1;
        int k = 2;
        while(k<=n1 && k <= n2)
        {
            if(n1%k==0 && n2%k==0)
            gcd = k;
            k++;
        }
        return gcd;
    }
}