import java.util.Scanner;
public class ojasva 
{
    public static void main(String[] args) 
        {
            Scanner in=new Scanner(System.in);
            System.out.println("Enter number of elements in matrix:");
            int num=in.nextInt();
            int n=(int)Math.sqrt(num);
            int [][]a=new int [n][n];
            
            // input matrix
            System.out.println("Enter the matrix elements:");
            for(int i=0;i<n;i++)
            {
                for(int j=0;j<n;j++)
                {
                    a[i][j]=in.nextInt();
                }
            }

            //Checking the consecutive elements
            int flag=0;

            //Consecutive checking row and column together
            for(int i=0;i<n;i++)
            {
                int count=0;
                int count2=0;
                int count3=0;
                int count4=0;
                for(int j=0;j<n-1;j++ )
                {
                    if(a[i][j]==a[i][j+1]+1)
                    {
                        count++;
                    }
                    if(a[j][i]==a[j+1][i]+1)
                    {
                        count2++;
                    }
                    if(a[i][j]==a[i][j+1]-1)
                    {
                        count3++;
                    }
                    if(a[j][i]==a[j+1][i]-1)
                    {
                        count4++;
                    }
                }
                if(count>=n-1 || count3>=n-1)
                {
                    System.out.println("Consecutive Elements found in row :"+ (i+1));
                    flag=1;
                }
                if(count2>=n-1 || count4>=n-1)
                {
                    System.out.println("Consecutive Elements found in column :"+ (i+1));
                    flag=1;
                }
            }
            //Checking consecutive in diagonals
            int count=0;
            int count1=0;
            int count2=0;
            int count3=0;

            for(int i=0,j=n-1;i<n-1;i++,j--)
            {
                if(a[i][i]==a[i+1][i+1]+1)
                count++;

                if(a[i][i]==a[i+1][i+1]-1)
                count1++;

                if(a[i][j]==a[i+1][j-1]+1)
                count2++;

                if(a[i][j]==a[i+1][j-1]+1)
                count3++;
            }
            if(count>=n-1 || count1>=n-1)
            {
                System.out.println("Consecutive elements found in first diagonal");
                flag=1;
            }
            if(count2>=n-1 || count3>=n-1)
            {
                System.out.println("Consecutive elements found in second diagonal");
                flag=1;
            }

            //if no consecutives elements are found 
            if(flag==0)
            {
                System.out.println("No consecutive elements found");
            }
        }
}

