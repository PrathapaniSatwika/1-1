class testxx { 
	public static void main(String args[]) 
	{ 
		System.out.println("VITAP"); 
	} 
} 












/*
1)public: It is an access specifier which allows the JVM(Java Virtual Machine) to access the main method from anywhere.
2)static: static keyword allows the JVM to access the main method without any instance(object).
3)void: It specifies that the main method doesn’t return anything.
4)main: name of the method(function) configured in JVM.
5)String args[]: Command line arguments.
*/