/**
 * The Java Math copySign() method copies the sign of the second argument and assign it to the first argument.
 */
class Main {
    public static void main(String[] args) {
  
      // copy sign of double arguments
      double x = 9.6d;
      double y = -6.45;
      System.out.println(Math.copySign(x, y));  // -9.6
  
      // copy sign of float arguments
      float a = -4.5f;
      float b = 7.34f;
      System.out.println(Math.copySign(a, b));  // 4.5
  
    }
  }