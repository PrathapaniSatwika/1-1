//The Java Math addExact() method adds the specified numbers and returns it.

import java.lang.Math;

class Main {
  public static void main(String[] args) {

    // create int variable
    int a = 24;
    int b = 33;

    // addExact() with int arguments
    System.out.println(Math.addExact(a, b));  // 57

    // create long variable
    long c = 12345678l;
    long d = 987654321l;

    // addExact() with long arguments
    System.out.println(Math.addExact(c, d));  // 999999999
  }
}




/**
 * 
 * In the above example, we have used the Math.addExact() method with the int and long variables to calculate the sum
 */