public class testtt 
{ 
	public String function(long i, long f) //int float
	{ 
		return ("vit"); 
	}
	public String function(double i, float f) //int>long>float>double
	{ 
		return ("VIT"); //triggered
	} 
	public static void main(String[] args) 
	{ 
		testtt obj = new testtt(); 
		System.out.println(obj.function(4,4));	 
	} 
} 

























/***Different type of arguments contribute towards method overloading as the signature of methods is changed with type of attributes. Whichever matches the attributes is obviously called in Method Overloading. Here we are pass first attributes double not float. */