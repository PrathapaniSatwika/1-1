/***
 * 
 * Example: Java Math cbrt()

 * 
 * 
 * */
class Main {
    public static void main(String[] args) {
  
      // create a double variable
      double value1 = Double.POSITIVE_INFINITY;
      double value2 = 27.0;
      double value3 = -64;
      double value4 = 0.0;
  
      // cube root of infinity
      System.out.println(Math.cbrt(value1));  // Infinity
  
      // cube root of a positive number
      System.out.println(Math.cbrt(value2));  // 3.0
  
      // cube root of a negative number
      System.out.println(Math.cbrt(value3));  // -4.0
  
      // cube root of zero
      System.out.println(Math.cbrt(value4));  // 0.0
    }
  }




  /***
   * In the above example, we have used the Math.cbrt() method to compute the cube root of infinity, positive number, negative number, and zero.

Here, Double.POSITIVE_INFINITY is used to implement positive infinity in the program.

When we pass an integer value to the cbrt() method, it automatically converts the int value to the double value.

int a = 125;

Math.cbrt(a);   // returns 5.0
   * 
   * 
   */
