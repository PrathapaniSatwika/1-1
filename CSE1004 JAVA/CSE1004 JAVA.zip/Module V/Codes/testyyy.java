/****
 * The static keyword is a non – access modifier in Java which can be used for variables, methods, and block of code. Static variables in Java belong to the class i.e it is initialized only once at the start of the execution. By using static variables a single copy is shared among all the instances of the class, and they can be accessed directly by class name and don’t require any instance. The Static method similarly belongs to the class and not the instance and it can access only static variables but not non-static variables. 
*/

//static method access static variables
// Java program to check accessibility 
// of static variables inside 
// static mathods 

class testyyy { 

	// declaring variable 'a' as static 
	static int a = 5; 

	// main is also a static type 
	public static void main(String args[]) 
	{ 

		// accessing value of 
		// static variable 
		System.out.println("Static variable:" + a); 
	} 
}

