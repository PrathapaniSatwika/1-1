// Java program to demonstrate varargs 
class ww 
{ 
	// A method that takes variable number of integer 
	// arguments. 
	static void fun(int ...a) 
	{ 
		System.out.println("Number of arguments: " + a.length); 

		// using for each loop to display contents of a 
		for (int i: a) 
			System.out.print(i + " "); 
		System.out.println(); 
	} 

	// Driver code 
	public static void main(String args[]) 
	{ 
		// Calling the varargs method with different number 
		// of parameters 
		fun(100);		 // one parameter 
		fun(1, 2, 3, 4); // four parameters 
		fun();		 // no parameter 
	} 
} 









/***
 * The … syntax tells the compiler that varargs has been used and these arguments should be stored in the array referred to by a.
The variable a is operated on as an array. In this case, we have defined the data type of a as int. So it can take only integer values. The number of arguments can be found out using a.length, the way we find the length of an array in Java.
Note: A method can have variable length parameters with other parameters too, but one should ensure that there exists only one varargs parameter that should be written last in the parameter list of the method declaration.
 */