import java.util.Scanner;//import the scanner class
class prog1{
public static void main(String args[]){
Scanner scan=new Scanner(System.in);//create a scanner object
System.out.println("Enter a number for find factorial");
int num=scan.nextInt();//get input from user 

//call the function to find factorial

factorial(num); //invoking function/invocation

//another way to find factorial
}

static void factorial(int num)
{
int i,fact=1;
for(i=1; i<=num; i++)
{
fact=fact*i;//calculate the factorial using for loop
}
//return;
System.out.print("Factorial of the "+num+"is: "+fact);

}
}