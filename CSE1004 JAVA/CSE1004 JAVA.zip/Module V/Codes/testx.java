// A Java program with overloaded main() 
import java.io.*; 
  
public class testx { 
      
    // Normal main() 
    public static void main(String[] args) { 
        System.out.println("Welcome to VITAP"); 
        testx.main("Student"); 
    } 
  
    // Overloaded main methods 
    public static void main(String arg1) { 
        System.out.println("Hi, " + arg1); 
        testx.main("You are in SCOPE"); 
    } 
    
} 








/****
 * The main method in Java is no extra-terrestrial method. Apart from the fact that main() is just like any other method & can be overloaded in a similar manner, JVM always looks for the method signature to launch the program.

The normal main method acts as an entry point for the JVM to start the execution of program.
We can overload the main method in Java. But the program doesn’t execute the overloaded main method when we run your program, we need to call the overloaded main method from the actual main method only.
 */