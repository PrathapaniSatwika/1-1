// initializing with input values
import java.util.*;
public class array1
{
public static void main(String[] args)
{
    Scanner in = new Scanner(System.in);
    int matrix[][] = new int[n][m];//array of [1d] arrays
    System.out.println("Enter " + matrix.length + " rows and " +
matrix[0].length + " columns: ");
for (int i = 0;i<matrix.length;i++)//how many 1D arrays are present in matrix==2
{
    for(int j=0;j<matrix[i].length;j++)//row wise length of 1st 1D array
    {
        matrix[i][j]=in.nextInt();
    }
}
for (int i = 0;i<matrix.length;i++)
{
    for(int j=0;j<matrix[0].length;j++)
    {
        System.out.print(matrix[i][j]+" ");
    }
    System.out.println("");
}
}
}