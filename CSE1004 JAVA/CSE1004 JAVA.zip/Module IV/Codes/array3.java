class array3 {
    public static void main(String[] args) 
    {
     
      // create an array
      int[] age = {12, 4, 5,6 ,8};
      int a;
      // loop through the array
      // using for loop
      System.out.println("Using for-each Loop:");
      //int a;
      for( a : age) {//for-each loops
        //System.out.println(a);
      }
      System.out.println(a);
    }
  }