/* WAP to find number of items above the average of all items*/
import java.util.Scanner;
public class array1
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        //System.out.print("Enter number of items");
        //int n = sc.nextInt();//specified n=size of array5
        double [] numbers = new double[10];//passing
        double sum = 0;

        System.out.println("Enter the numbers:");
        for (int i = 0;i < n;i++)//10x
        {
            numbers[i] = sc.nextDouble();//1 D double array
            sum += numbers[i];
        }
        double average = sum/n;//sum of all elements

        int count = 0;
        for (int i = 0; i < n; i++)
        {
            if(numbers[i] > average)
            count++;
        }
        System.out.println("Average is:"+average);
        System.out.println("Number of elements above average is "+count);
    }
}