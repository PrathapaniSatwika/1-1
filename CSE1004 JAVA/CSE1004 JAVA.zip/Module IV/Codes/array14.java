/**block exchange
 * 
 * BEFORE EXCHANGE OF ARRAY
21//1
12//2 block1
15//3
32 middle
16//1
17//2 block2
22//3
AFTER EXCHANGE OF ARRAY
16
17
22
32
21
12
15
 * 
 * 
 * 
 * 
 */
// 6,17
public class array14
{
public static void main (String [] args)
{
int ar[]={21,12,15,32,16,17};//6

for (int i = 0; i < ar.length; i++)
{
System.out.println (ar[i]);
}
int n;
if (ar.length%2==0)//
n=ar.length/2;//ar[3]
else
n= (ar.length/2) +1;//3+1
for (int i=0; i<ar.length/2; i++)//3
int t=ar[i];//t=ar[0]
ar[i] =ar [n+i];//ar[0]=ar[3+0]
ar [n+i]=t;
}

for (int i = 0; i < ar.length; i++)
{
System.out.println (ar[i]);
}
}
}
