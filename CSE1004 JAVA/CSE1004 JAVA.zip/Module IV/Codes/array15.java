//occurrence of an element
import java.util.*;
public class array15
{
    public static void main(String[] args)
    {
        int arr[] = {22,11,23,45,17,17,17};
        Scanner sc = new Scanner(System.in);
        int ele = sc.nextInt();
        int count = 0;
        for(int i=0;i<arr.length;i++)
        {
            if(ele==arr[i])
            count++;
        }
        if(count>0)
        {
            System.out.print("element occurred"+" "+count+" "+"times");
        }
        else
        {
            System.out.print("no occurrence");
        }

    }
}