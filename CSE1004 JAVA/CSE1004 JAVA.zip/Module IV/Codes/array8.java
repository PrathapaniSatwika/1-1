import java.util.Scanner;
public class array8
{
public static void main (String [ ] args)
{
Scanner sc= new Scanner (System.in);
System.out.println ("enter the size");
int length= sc.nextInt ();
int arr [ ] =new int [length];
System.out.println ("enter the "+length+" elements");
    for (int i = 0; i < arr.length; i++)
    {
        arr[i] =sc.nextInt ();//inp
    }
System.out.println ("Before Reverse of an Array");
    for (int i = 0; i < arr.length; i++)
    {
        System.out.println ("arr ["+i+"] ---->"+arr[i]);//   o/p
    }
  for (int i = 0; i < arr.length/2; i++)
    {
        int t=arr[i];//0
        arr[i] =arr [arr.length-1-i];
        arr [arr.length-1-i] = t;
    }
    
System.out.println ("After Reverse of an Array");
    for (int i = 0; i < arr.length; i++)
    {
        System.out.println ("arr ["+i+"] ---->"+arr[i]);
    }
} 
