//distinct elements,flags

public class array17
{
    public static void main (String [] args)
    {
           
    int ar1 [] = {12, 13, 23, 15, 11, 16};//6
    int ar2 [] = {53, 26, 23, 15, 18, 13};//6
    System.out.println ("Distinct elements from given two arrays");
    for (int i=0; i<ar1.length; i++)
    {
        int find=0;//flag
        for (int j=0; j<ar2.length; j++)
        {
            if (ar1 [i] == ar2 [j])//12neq53
            {
                find=1;
                break;
            }
        } 
            if (find==0)
            System.out.println (ar1 [i]);
    }
    for (int i=0; i<ar2.length; i++)
    {
        int find=0;
        for(int j=0; j<ar1.length; j++)
        {
            if (ar2 [i] == ar1 [j])
            {
                find=1;
                break;
            }
        }
        if (find==0)
        System.out.println (ar2 [i]);
    }
    }
}