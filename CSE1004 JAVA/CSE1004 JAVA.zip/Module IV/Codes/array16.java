//common element between arrays
public class array16
{
    public static void main(String[] args)
    {
        int[] a = {12,13,14,15,16,17};
        int[] b = {8,9,10,11,12,13,14};
        System.out.print("common elements are ");
        for(int i=0;i<a.length;i++)//i=0
        {
            for(int j=0;j<b.length;j++)//j=0-5
            {
                if(a[i]==b[j])//a[0]=b[0],b[1],b[2]......b[n]
                {
                    System.out.print(a[i]+" ");
                    break;
                }
            }
        }
    }
}