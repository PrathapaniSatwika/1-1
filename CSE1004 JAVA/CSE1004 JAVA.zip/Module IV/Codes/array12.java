//highest contiguous sum of two elements in array
public class array12
{
public static void main (String [] args)
{
int ar[]={21,12,15,32,16,17,22};
//
int inx=0;
int big=ar [0] +ar [1];//sum
for (int i=1; i<ar.length-1; i++)//i=1
{
if (big<ar[i] + ar [i+1])//ar[0]+ar[1]<ar[1]+ar[2]
{
big=ar[i] +ar [i+1];//big=ar[1]+ar[2]
inx=i;//1
}
}
System.out.println ("sum of two element"+"----->"+big);
System.out.println ("the first element"+"--->"+ar [inx]);//ar[1]
System.out.println (" the second element"+"--->"+ar [inx+1]);//ar[2]
}
}