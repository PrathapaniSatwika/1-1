//What will be the output ?

class array11
{
public static void main (String [] args)
{
int ar [] = {11,17,20,25,35};//5//4
System.out.println ("Missing elements in given array are :");
for (int i=0;i<ar.length-1 ;i++ )//0-3
{
for (int j=ar[i];j<ar[i+1]; j++ )//ar[5]
{
System.out.print (j+" ");
}
}
}
}